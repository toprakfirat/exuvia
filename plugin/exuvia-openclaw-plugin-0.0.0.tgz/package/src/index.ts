import { definePluginEntry } from "openclaw/plugin-sdk/plugin-entry";
import { createPlayAnimationTool, type AnimationCatalogueEntry } from "./animation-tool.js";

type ExuviaAvatarConfig = {
  // Either avatarPath or fbxPath is accepted at the data layer. avatarPath is
  // the canonical name now that we support both .fbx and .glb. fbxPath stays
  // as a legacy alias.
  avatarPath?: string;
  fbxPath?: string;
  fbxScale?: number;
  voiceOnChannels?: boolean;
  // Per-avatar opt-in for the personality rewrite pass. When true, every
  // outbound assistant message is run through a second LLM call that
  // re-styles it in the avatar's voice (per SOUL.md). Off by default —
  // doubles latency and can mangle structured replies.
  personalityRewrite?: boolean;
  postProcessing?: Record<string, unknown>;
  animations?: AnimationCatalogueEntry[];
};

// Channels where attaching a voice note makes sense. Desktop / control-ui
// surfaces are skipped because the desktop app plays TTS locally.
const CHANNELS_WITH_VOICE_NOTES = new Set([
  "telegram",
  "whatsapp",
  "imessage",
  "discord",
  "signal",
  "matrix",
  "googlechat",
  "slack",
  "line",
]);

type ExuviaPluginConfig = {
  avatars?: Record<string, ExuviaAvatarConfig>;
};

function readAvatarConfig(
  pluginConfig: Record<string, unknown> | undefined,
  agentId: string | undefined,
): ExuviaAvatarConfig | undefined {
  const cfg = pluginConfig as ExuviaPluginConfig | undefined;
  if (!cfg?.avatars || !agentId) return undefined;
  return cfg.avatars[agentId];
}

// SOUL.md text cache, keyed by agentId. Refreshed lazily per turn — first
// time we need it we ask the host runtime for the workspace dir + read the
// file via dynamic import of node fs. Wrapped so a missing/disallowed fs
// module fails open rather than killing the hook.
const soulCache = new Map<string, string | null>();

async function readSoulForAgent(
  agentId: string | undefined,
  workspaceDir: string | undefined,
): Promise<string | null> {
  if (!agentId || !workspaceDir) return null;
  if (soulCache.has(agentId)) return soulCache.get(agentId) ?? null;
  try {
    // Dynamic import — keeps the static module graph clean of node:* so the
    // plugin entry can be bundled by tools that don't allow Node built-ins
    // at parse time. If fs isn't available, we just return null.
    const fs = await import("node:fs/promises");
    const path = await import("node:path");
    const os = await import("node:os");
    let dir = workspaceDir;
    if (dir === "~") dir = os.homedir();
    else if (dir.startsWith("~/") || dir.startsWith("~\\")) {
      dir = path.join(os.homedir(), dir.slice(2));
    }
    const filePath = path.join(dir, "SOUL.md");
    const text = await fs.readFile(filePath, "utf8");
    soulCache.set(agentId, text);
    return text;
  } catch {
    soulCache.set(agentId, null);
    return null;
  }
}

// Heuristics for "this reply has structured content we shouldn't paraphrase."
// If any match, skip the rewrite — preserving facts > showing voice.
const STRUCTURED_PATTERNS = [
  /^MEDIA:/m,
  /\[\[audio_as_voice\]\]/,
  /\[\[reply_to/,
  /\[embed\b/,
  /```/, // code fence
  /<tool_call>|<\/tool_call>|<function_call>|<\/function_call>/,
  /\b\d{1,2}:\d{2}(?::\d{2})?\b/, // timestamps like 3:00, 14:30
  /https?:\/\//, // URLs
];

function looksStructured(content: string): boolean {
  if (!content) return true;
  if (content.length < 8) return true;
  return STRUCTURED_PATTERNS.some((re) => re.test(content));
}

export default definePluginEntry({
  id: "exuvia",
  name: "Exuvia",
  description:
    "Character-first avatar layer for OpenClaw. Adds a play_animation tool driven by per-avatar animation catalogues.",
  // Most exuvia config changes (avatar metadata, animations, post-processing)
  // are read on demand by the desktop app or by the play_animation tool — no
  // restart needed. Only changes to whether the plugin itself is enabled
  // require a reload, and openclaw handles that on its own.
  reload: {
    restartPrefixes: [],
  },
  register(api) {
    const log = (msg: string) => api.logger.info(`[exuvia] ${msg}`);

    log("registering");

    // Tool: play_animation. The factory receives ctx with agentId / runtimeConfig
    // so we can build a tool description that includes the active avatar's
    // animation catalogue.
    //
    // The `{ name }` option is required when using a factory — the runtime
    // catalog can't resolve the name without invoking the factory, so we
    // declare it up-front. Must match the entry in contracts.tools.
    api.registerTool(
      (ctx) => {
        const agentId = ctx.agentId;
        const avatar = readAvatarConfig(api.pluginConfig, agentId);
        return createPlayAnimationTool({
          agentId,
          animations: avatar?.animations,
          log,
        });
      },
      { name: "play_animation" },
    );

    // Hook: before_prompt_build. No-op for v1. Phase 2+ may inject avatar-aware
    // context here (e.g. a short list of available animations as a hint, or a
    // per-channel tone tweak). Personality itself lives in AGENTS.md / SOUL.md
    // in each agent's workspace and is loaded by claw natively.
    api.on(
      "before_prompt_build",
      async (_event) => {
        return;
      },
      { priority: 50 },
    );

    // Hook: message_sending (priority 100, runs first).
    // Personality rewrite pass — when enabled per-avatar, runs the outbound
    // text through a second LLM call to restyle it in the character's voice.
    // The voice-note hook below (priority 50) sees the rewritten content,
    // so chat-channel users hear the in-character voice.
    api.on(
      "message_sending",
      async (event, ctx) => {
        try {
          const agentId =
            (ctx as { agentId?: string } | undefined)?.agentId ??
            (event as { agentId?: string }).agentId ??
            undefined;
          const avatar = readAvatarConfig(api.pluginConfig, agentId);
          log(
            `rewrite hook fired: agent=${agentId ?? "?"} ` +
              `enabled=${Boolean(avatar?.personalityRewrite)} ` +
              `hasRuntimeLlm=${Boolean((api.runtime as { llm?: unknown })?.llm)}`,
          );
          if (!avatar?.personalityRewrite) return;

          const content =
            typeof (event as { content?: unknown }).content === "string"
              ? (event as { content: string }).content
              : "";
          if (!content.trim()) {
            log("rewrite skip: empty content");
            return;
          }
          if (looksStructured(content)) {
            log(`rewrite skip: structured content (${content.length} chars)`);
            return;
          }

          // Find the agent's workspace from agents.list config, then read SOUL.md.
          const agentsList =
            (api.config as { agents?: { list?: Array<{ id?: string; agentId?: string; workspace?: string }> } })
              ?.agents?.list ?? [];
          const agentRow = agentsList.find(
            (a) => (a.id ?? a.agentId) === agentId,
          );
          const workspace = agentRow?.workspace;
          const soul = await readSoulForAgent(agentId, workspace);
          if (!soul || !soul.trim()) return;

          const llmRuntime = (api.runtime as {
            llm?: {
              complete?: (params: {
                messages: Array<{ role: string; content: string }>;
                purpose?: string;
                maxTokens?: number;
                temperature?: number;
              }) => Promise<{ text?: string }>;
            };
          }).llm;
          if (!llmRuntime?.complete) return;

          const systemPrompt =
            "You rewrite assistant replies in a specific character's voice.\n" +
            "Character voice description follows. Embody it — don't reference it.\n\n" +
            "===CHARACTER VOICE===\n" +
            soul.trim() +
            "\n===END===\n\n" +
            "Rules you MUST follow:\n" +
            "- Preserve every fact, name, number, and quoted string EXACTLY.\n" +
            "- Output ONLY the rewritten reply. No preamble, no commentary, no quotes.\n" +
            "- Match the original length roughly. Don't pad or shorten substantially.\n" +
            "- Stay in character even when the user asks who you are.";

          const result = await Promise.race([
            llmRuntime.complete({
              messages: [
                { role: "system", content: systemPrompt },
                { role: "user", content: content.trim() },
              ],
              purpose: "exuvia.personality-rewrite",
              maxTokens: Math.max(200, Math.ceil(content.length * 1.5)),
              temperature: 0.7,
            }),
            new Promise<never>((_resolve, reject) =>
              setTimeout(() => reject(new Error("rewrite timeout")), 20_000),
            ),
          ]).catch((err) => {
            api.logger.warn(`[exuvia] personality rewrite failed: ${String(err)}`);
            return null;
          });

          const rewritten = result?.text?.trim();
          if (!rewritten) {
            log(`rewrite skip: empty llm result (raw=${JSON.stringify(result)?.slice(0, 200)})`);
            return; // fail open — original goes through
          }
          log(`rewrite ok: ${content.length} -> ${rewritten.length} chars`);
          return { content: rewritten };
        } catch (err) {
          api.logger.warn(`[exuvia] personality rewrite hook failed: ${String(err)}`);
          return;
        }
      },
      { priority: 100, timeoutMs: 30_000 },
    );

    // Hook: message_sending. For chat-channel deliveries, optionally attach a
    // TTS voice note when the avatar is configured with voiceOnChannels=true.
    // Skipped for desktop / control-ui surfaces (they play audio locally) and
    // for any avatar that didn't opt in.
    api.on(
      "message_sending",
      async (event, ctx) => {
        try {
          const provider =
            (ctx as { messageProvider?: string } | undefined)?.messageProvider ??
            (event as { messageProvider?: string }).messageProvider ??
            null;
          if (!provider || !CHANNELS_WITH_VOICE_NOTES.has(provider)) return;

          const agentId =
            (ctx as { agentId?: string } | undefined)?.agentId ??
            (event as { agentId?: string }).agentId ??
            undefined;
          const avatar = readAvatarConfig(api.pluginConfig, agentId);
          if (!avatar?.voiceOnChannels) return;

          const content =
            typeof (event as { content?: unknown }).content === "string"
              ? (event as { content: string }).content
              : "";
          if (!content.trim()) return;
          // Don't double-process if the message already carries a voice note.
          if (content.includes("[[audio_as_voice]]")) return;

          // Strip any inline directives the agent already produced before TTS,
          // so we synthesize the user-facing wording, not protocol metadata.
          const spoken = content
            .replace(/\[\[[^\]]+\]\]/g, "")
            .replace(/^MEDIA:.*$/gm, "")
            .trim();
          if (!spoken) return;

          // api.runtime.tts.textToSpeech returns audio buffer + format. We
          // need a delivered file path on disk — the simplest path is to ask
          // the gateway runtime for it. If textToSpeech writes to a temp file,
          // we can attach that path; otherwise we'd need to write it ourselves.
          // openclaw's runtime helper returns { audioPath } from tts.convert
          // semantics, so use the same lower-level path: api.runtime.tts.
          const ttsRuntime = (api.runtime as { tts?: {
            textToSpeech?: (params: {
              text: string;
              cfg: typeof api.config;
              channel?: string;
            }) => Promise<{ audioPath?: string; outputFormat?: string }>;
          } | undefined }).tts;
          if (!ttsRuntime?.textToSpeech) return;

          const result = await ttsRuntime.textToSpeech({
            text: spoken,
            cfg: api.config,
            channel: provider,
          });
          if (!result?.audioPath) return;

          const newContent = `${content}\nMEDIA: ${result.audioPath}\n[[audio_as_voice]]`;
          return { content: newContent };
        } catch (err) {
          api.logger.warn(`[exuvia] message_sending hook failed: ${String(err)}`);
          return;
        }
      },
      { priority: 50 },
    );

    // (No gateway RPC methods. The desktop app reads avatar metadata directly
    // from the standard config.get response — that data is plain config under
    // plugins.entries.exuvia.config.avatars. We tried registerGatewayMethod
    // for namespaced reads but this build of openclaw rejects external-plugin
    // RPCs as "unknown method" even with explicit scope.)

    log("registered");
  },
});
