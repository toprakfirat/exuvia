import type { AnyAgentTool } from "openclaw/plugin-sdk/plugin-entry";
import { Type } from "typebox";

const PlayAnimationSchema = Type.Object({
  name: Type.String({
    description: "Animation clip name from this avatar's catalogue.",
  }),
});

export type AnimationCatalogueEntry = {
  name: string;
  description?: string;
  tags?: string[];
  loop?: boolean;
  durationMs?: number;
  gifPath?: string;
};

export function createPlayAnimationTool(opts: {
  agentId?: string;
  animations?: AnimationCatalogueEntry[];
  log: (msg: string) => void;
}): AnyAgentTool {
  const { agentId, animations, log } = opts;
  const catalogueText = (animations ?? [])
    .map((a) => {
      const tags = a.tags?.length ? ` [${a.tags.join(", ")}]` : "";
      const desc = a.description ? ` — ${a.description}` : "";
      return `- ${a.name}${tags}${desc}`;
    })
    .join("\n");

  const description =
    catalogueText.length > 0
      ? `Play an animation on the avatar. Use sparingly — only when the animation adds emotional meaning. Available animations:\n${catalogueText}`
      : "Play an animation on the avatar. Use sparingly — only when the animation adds emotional meaning.";

  return {
    label: "Play animation",
    name: "play_animation",
    description,
    parameters: PlayAnimationSchema,
    execute: async (_toolCallId, args) => {
      const params = args as { name?: unknown };
      const name = typeof params.name === "string" ? params.name.trim() : "";
      if (!name) {
        return {
          content: [{ type: "text" as const, text: "play_animation: name required" }],
          details: { animation: null, agentId, hasMedia: false, error: "name required" },
        };
      }
      log(`play_animation fired: agent=${agentId ?? "?"} name=${name}`);

      // Look up the matching catalogue entry — case-insensitive — to find a
      // pre-rendered gif if the user has baked one. Channel adapters that
      // support media (Telegram, Discord, WhatsApp, iMessage) will deliver it;
      // text-only channels strip media gracefully.
      const entry = (animations ?? []).find(
        (a) => a.name.toLowerCase() === name.toLowerCase(),
      );
      const text = `(played ${name})`;
      const lines: string[] = [text];
      if (entry?.gifPath) {
        // MEDIA: directive — local absolute or ~/ paths are supported.
        lines.push(`MEDIA: ${entry.gifPath}`);
      }
      return {
        content: [{ type: "text" as const, text: lines.join("\n") }],
        details: { animation: name, agentId, hasMedia: Boolean(entry?.gifPath) },
      };
    },
  };
}
